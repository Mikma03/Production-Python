from fast import pick as who_cares

place = who_cares()
print("Let's go to", place)
