def just_do_it(text):
    return text.capitalize()
