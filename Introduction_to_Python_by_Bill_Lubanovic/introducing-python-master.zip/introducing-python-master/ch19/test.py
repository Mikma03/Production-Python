print('Oops')
