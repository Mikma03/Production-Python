def iso():
    from datetime import date
    print(date.today().isoformat())
