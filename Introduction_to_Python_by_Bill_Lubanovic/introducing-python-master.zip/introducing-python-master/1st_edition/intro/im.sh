#!/bin/sh
language=0
echo "Language $language: I am the shell. So there."
