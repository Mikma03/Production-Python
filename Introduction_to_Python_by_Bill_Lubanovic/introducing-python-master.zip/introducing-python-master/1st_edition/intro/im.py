language = 7
print("Language %s: I am Python. What's for supper?" % language)
