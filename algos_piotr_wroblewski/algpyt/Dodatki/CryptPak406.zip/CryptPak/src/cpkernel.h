
#ifndef __CPKERNEL_H
#define __CPKERNEL_H


#ifdef __cplusplus
extern "C" {
#endif

#include <stddef.h>

#include "cpconfig.h"

void CRYPTPAK_API CryptPak_Init();

#ifdef __cplusplus
}
#endif

#endif









