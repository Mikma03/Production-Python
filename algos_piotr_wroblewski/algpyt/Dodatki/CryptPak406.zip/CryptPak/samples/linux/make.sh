#!/bin/sh
gcc ../../src/*.c ../cpp/*.cpp -DUNIX -I../../src -I../cpp -o testcryptpak