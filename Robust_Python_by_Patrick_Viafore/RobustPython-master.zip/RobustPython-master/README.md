# RobustPython
Code Examples for Robust Python book

Note that to get many of the examples use dummy types and data to not take away from the book example.

For example, complex types might be aliased as a string and instances are just random snippets of text.
Additionally, functions might just return hardcoded values.

The meat of the book examples are unchanged from the text, however. Feel free to stick in a `breakpoint()`
in the code to further understand how it works.
