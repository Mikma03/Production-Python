assert type(3.14) == float
assert type("This is another boring example") == str
assert type(["Even", "more", "boring", "examples"]) == list
