from typing import TypeVar

def double(x):
    return x + x

assert double(3) == 6
assert double("abc") == "abcabc"
