from typing import Final

x: Final[int] = 5
x = 3
