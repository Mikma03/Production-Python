a: int = 5
a = "string"
