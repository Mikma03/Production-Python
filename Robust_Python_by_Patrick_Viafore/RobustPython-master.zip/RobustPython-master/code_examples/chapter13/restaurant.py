name = "Chameleon Café"
address = "123 Fake St."

standard_lunch_entries = ['BLTSandwich']
other_entries = ['BLTSandwich']

def render_menu() -> str:
    # Code to render a menu 
    return "BLAH"
