#! /bin/bash -eu
python code_examples/chapter14/read_restaurant.py
python code_examples/chapter14/restaurant_pydantic.py
python code_examples/chapter14/validators.py
python code_examples/chapter14/validators_2.py
python code_examples/chapter14/validators_custom.py
python code_examples/chapter14/simple_model.py


echo "All Chapter 14 Tests Passed"
