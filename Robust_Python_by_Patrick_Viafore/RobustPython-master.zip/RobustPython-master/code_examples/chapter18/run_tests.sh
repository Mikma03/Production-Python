#! /bin/bash -eu
python code_examples/chapter18/rxpy.py

mypy code_examples/chapter18/*.py

echo "All Chapter 18 Tests Passed"
