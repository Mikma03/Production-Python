#! /bin/bash -eux
py.test code_examples/chapter21

echo "All Chapter 21 Tests Passed"
