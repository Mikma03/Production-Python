#! /bin/bash -eu
python code_examples/chapter19/pluggable.py

echo "All Chapter 19 Tests Passed"
